export default interface Opcao {
  cod: string
  familia: string
  hora?: string
  neg?: number
  qtt?: number
  vtt?: number
  npr?: number
  qpr?: number
  vpr?: number
  type: string
  nprmmneg?: number
  qprmmqtt?: number
  vprmmvtt?: number
}
