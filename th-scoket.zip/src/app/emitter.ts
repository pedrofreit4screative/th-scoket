import net from 'net'
import Ativo from '../interfaces/ativo'
import Opcao from '../interfaces/options'
import { send } from '../socket/socket'
import { Redis, RedisIn } from '../utils/redis'
const { calculos, calculosOpcoes } = require('./count')
import { checkHoliday, filterData, keysArrays, writeEnfoque } from './filters'

// Socket Enfoque
let clients: net.Socket

const HOST = process.env.ENFOQUE_HOST?.toString() || 'socket3.enfoque.com.br'
const PORT = parseInt(process.env.ENFOQUE_PORT) || 8090
const credentials = 'L:TRADEHUNTER_FEED:HUNTER:NTM:NTB:TRD'

const ativos = {}
const opcoes = {}

const openConnection = async () => {
  if (!(await checkHoliday())) return

  // Conectar com o enfoque
  clients = net.connect({ host: HOST, port: PORT }, () => {
    console.log('[Enfoque] - Conexão realizada com sucesso!')
    clients.write(`${credentials}\r\n`)

    writeEnfoque(
      (ativos) => {
        clients.write(`S:${ativos.cod}\r\n`)
        return null
      },
      (opcoes) => {
        clients.write(`S:${opcoes.cod}\r\n`)
        return null
      }
    )
  })
  let dataFilter: Ativo[] | Opcao[] = []
  const ativosSave: Ativo[] = []

  clients.on('data', (data) => {
    const d = data.toString('utf-8')

    const quoteT = d.match(/([T]:)[^\r]*/g) || []
    quoteT.forEach(async (q) => {
      const dadaFilter = filterData(q)
      dataFilter.push(dadaFilter)
    })
  })
  const redis = new Redis()
  const ativos = await redis.getCache<Ativo[]>('ativos')
  const opcoes = await redis.getCache<Opcao[]>('opcao')

  const { mediaVolume, minEMax, dadosFechs, dadosEstocs, mediasVolumeOpcoes } =
    await keysArrays()

  let familiasUpdate = mediasVolumeOpcoes
  const lastOpcoes = {}

  setInterval(async () => {
    const filter = dataFilter

    dataFilter = []

    filter.forEach((item) => {
      ativos.map(async (ativo) => {
        if (item.cod === ativo.cod) {
          ativosSave.push(item)

          const parseAtivo = await calculos(
            {
              ...item,
              volumes: {},
              minmax: {},
              estocastico: {},
              pivotpoint: {},
              larry: {},
              didi: {},
              ifr: {},
              mediasmoveis: {},
              cruzamentomedias: {},
              trix: {},
              dr: {},
              adl: {},
              macd: {},
              obv: {},
              candleStick: {},
            },
            mediaVolume,
            minEMax,
            dadosFechs,
            dadosEstocs
          )


          send('ativo', item)
        }
      })
      opcoes.map(async (opcao) => {
        if (item.cod === opcao.cod) {
          if (lastOpcoes[item.cod]) {
            await calculosOpcoes(
              item,
              lastOpcoes[item.cod],
              familiasUpdate[opcao.familia],
              (familia) => {
                lastOpcoes[item.cod] = familia
              }
            )
            lastOpcoes[item.cod] = item
          } else {
            await calculosOpcoes(
              item,
              null,
              familiasUpdate[opcao.familia],
              (familia) => {
                lastOpcoes[item.cod] = item
              }
            )
          }

          //await calculosOpcoes(item, familiasUpdate[opcao.familia])
        }
      })
    })
  }, 5000)

  clients.on('close', (hadError) => {
    // TODO gravar log
    console.log('close', hadError)
  })

  clients.on('error', (err) => {
    // TODO gravar log
    console.log('error', err)
  })

  clients.on('end', () => {
    // TODO gravar log
    console.log('disconnected from server')
  })
}

openConnection()
