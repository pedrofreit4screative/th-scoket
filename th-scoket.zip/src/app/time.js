const { format, isSaturday, isSunday } = require('date-fns')

let tempoDecorrido = 1
let minutosDecorridos = 1
let leilao = false
let hojeFeriado = false
let datacompleta = null
let janelaEnfoque = false
let receiveQuote = true

const timeLocal = {
  horaLeilao: '09:45:00',
  horaAbre: '10:00:00',
  horaFecha: '18:00:00',
}

const timeProd = {
  startEnfoque: '11:00:00',
  horaLeilao: '12:45:00',
  horaAbre: '13:00:00',
  horaFecha: '20:00:00',
  horaFechaLeilao: '21:00:00',
}

async function calculaTempo() {
  let hoje = new Date()
  const dia = hoje.getDate()
  const mes = hoje.getMonth() + 1
  const ano = hoje.getFullYear()

  datacompleta =
    mes.toString().length === 1 && dia.toString().length !== 1
      ? ano + '-' + 0 + mes + '-' + dia
      : mes.toString().length !== 1 && dia.toString().length === 1
      ? ano + '-' + mes + '-' + 0 + dia
      : mes.toString().length === 1 && dia.toString().length === 1
      ? ano + '-' + 0 + mes + '-' + 0 + dia
      : ano + '-' + mes + '-' + dia

  const horaAgora = Date.parse(hoje) /* + 10800000 */
  //console.log(format(horaAgora, "HH':'mm"));

  const timeUso = timeProd

  const startEnfoque = Date.parse(datacompleta + 'T' + timeUso.startEnfoque)
  const hojeLeilao = Date.parse(datacompleta + 'T' + timeUso.horaLeilao)
  const hojeAbre = Date.parse(datacompleta + 'T' + timeUso.horaAbre)
  const hojeFecha = Date.parse(datacompleta + 'T' + timeUso.horaFecha)
  const hojeFechaLeilao = Date.parse(
    datacompleta + 'T' + timeUso.horaFechaLeilao
  )

  const feriados = ['12/10', '02/11', '24/12', '25/01']
  const hojeFormatado = format(new Date(), "dd'/'MM")

  if (feriados.indexOf(hojeFormatado) !== -1) {
    hojeFeriado = true
  } else {
    hojeFeriado = false
  }

  tempoDecorrido =
    horaAgora < hojeAbre ||
    horaAgora > hojeFecha ||
    isSaturday(horaAgora) ||
    isSunday(horaAgora) ||
    feriados.indexOf(hojeFeriado) !== -1
      ? 1
      : (Math.min(horaAgora, hojeFecha) - hojeAbre) / 25200000
  //console.log('TD', tempoDecorrido);
  minutosDecorridos = hoje.getMinutes() / 60

  if (
    horaAgora >= hojeLeilao &&
    horaAgora <= hojeAbre &&
    !isSaturday(horaAgora) &&
    !isSunday(horaAgora) &&
    feriados.indexOf(hojeFeriado) === -1
  ) {
    leilao = true
  } else {
    leilao = false
  }

  if (
    horaAgora >= startEnfoque &&
    horaAgora < hojeLeilao &&
    !isSaturday(horaAgora) &&
    !isSunday(horaAgora) &&
    feriados.indexOf(hojeFeriado) === -1
  ) {
    janelaEnfoque = true
  } else {
    janelaEnfoque = false
  }

  if (
    horaAgora <= hojeLeilao ||
    horaAgora >= hojeFechaLeilao ||
    isSaturday(horaAgora) ||
    isSunday(horaAgora) ||
    feriados.indexOf(hojeFeriado) !== -1
  ) {
    receiveQuote = false
  } else {
    receiveQuote = true
  }

  return {
    tempoDecorrido,
    minutosDecorridos,
    leilao,
    janelaEnfoque,
    receiveQuote,
  }
}

calculaTempo()

module.exports = {
  calculaTempo,
  tempoDecorrido,
  minutosDecorridos,
  leilao,
  janelaEnfoque,
  hojeFeriado,
  receiveQuote,
}
